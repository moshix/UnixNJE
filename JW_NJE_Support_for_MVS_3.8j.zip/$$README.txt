                      Hybrid NJE Support for MVS 3.8j
                      _______________________________


                             Proof of Concept
                             ----------------

Networking support of JES2 version 4.1 as distributed with MVS 3.8j is
limited to Remote Job Entry (RJE) over CTC and BSC connections. Network
Job Entry (NJE) is not part of JES2 and MVS at this level, making MVS 3.8j
an alien in the world of NJE networks driven by RSCS and JES2 as available
on many MVS and VM systems of the '80s and '90s.

Nowaday's, with a full TCP/IP stack being available to JES2 running on
z/OS, dedicated connections (native or SNA driven channel to channel
adapters or TP lines) are no longer needed to provide basic connectivity.
Instead, JES2 as well as RSCS support a TCP/IP based line driver called
TCPNJE.

Similar to JES2 on MVS 3.8j, the freely available RSCS implementations for
VM/370 also don't support NJE networking. Peter Coghlan succeeded to implement
a TCPNJE driver for RSCS on VM/370 running on Hercules 3.13. That same
approach, however, doesn't seem being feasible for MVS 3.8j: As opposed to
RSCS, JES2 is interwoven with almost all processing being done by MVS.
Modifying it at such a large scale as the implementation of NJE support would
require, would be a huge project with a large risk of breaking MVS
functionalities of all kinds or even rendering the whole system unusable.

A similar appoach as RSCS on VM/370, is, to provide a tool doing the heavy
lifting (file routing, transport and messaging) independly from JES2 and
to interface with the JES2 spool only as far as necessary to enable
end users to send and receive datasets. Even this would be complex when
starting at zero, but by far not as complex as a full NJE implementation
on JES2.

Given that "today"'s MVS 3.8j systems are running on emulators one can
even go as far as seeing the whole system (host OS, emulator, MVS) as
one NJE node, with each of these layers providing the tasks for which
they are most suited: The host OS providing network connectivity and
transport, the emulator providing point to point connectivity between
the host OS and MVS, and MVS itself handling only the presentation layer,
allowing the end user to initiate transmissions and to access received
data.

The present proof of concept implementation shows that it is feasible to
implement such a "hybrid" NJE support. It is based on the following
building blocks:

o FUNET-NJE, an NJE server implementation for UNIX systems, as found on
  https://github.com/fsword7/funetnje. This is an implementation dating
  back to the mid '90s. It will require quite some work to become a robust
  production tool being usable under today's rough networking conditions.
  However, there exists a commercial version of FUNET-NJE, called "NJE/IP
  Bridge" by SINE NOMINE (https://www.sinenomine.net/products/vm/njeip)
  that can probably shorten the way to come to a robust solution -- at a
  price. For the purpose of this proof of concept the source from github
  has been updated as minimally intrusive as possible to make it work on
  two platforms that are usable today: Intel Linux (most distributions)
  and Intel MacOS.

o A host operating system supporting BSD style socket communications and
  the execution of binaries compiled for 32-bit x86 Intel platforms. The
  32-bit requirement comes from the current state of the FUNET-NJE software,
  which is as of yet neither 64-bit nor big endian save. Currently two
  sets of binaries are available: 32-bit Intel binaries for Linux and for
  MacOS (too bad that the latest MacOS, Catalina, doesn't support 32-bit
  execution any more, so the source cleanup might become an issue soon).

o The TK4- MVS 3.8j Tur(n)key system at Update 08 or higher, running on
  the SoftDevLabs version of Hercules 4.2 (Hyperion) or higher with the
  TCPIP (X'75') instruction enabled.

The proof of concept configuration and a few commands querying the involved
systems are shown below. Any other setup can be configured easily, in particular
a connection to a VM/370 system running RSCS with Peter's TCPNJE extension
should work without further ado -- but has not been tested so far.

                  +-----------------------------------------+
                  |   FUNET-NJE on the Hercules Host as a   |
                  | subsitute for a full NJE implementation |
                  |       on a Hercules guest system        |
                  +-----------------------------------------+
                               Proof of Concept


                  +------------+               +------------+
                  |  CZHETH3C  |    TCPNJE     |    ZVM1    |
                  |  MVS 3.8j  |---------------|  z/VM 6.3  |
                  |  FUNET-NJE |               |    RSCS    |
                  +------------+               +------------+
                                                      |
                                                      |
                                                      | SNANJE
                                                      |
                                                      |
                  +------------+               +------------+
                  |    ZOS1    |    SNANJE     |    ZOS2    |
                  |  z/OS 1.10 |---------------|  z/OS 2.3  |
                  |    JES2    |               |    JES2    |
                  +------------+               +------------+


----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
send -c czheth3c q sys
CZHETH3C: FUNET-NJE version 3.2.(jwi)/1910201356, Lines status:
CZHETH3C: Line.0 ZVM1       1 (Q=0000)  ACTIVE      TCP
CZHETH3C:  7 streams in service.  WrSum: 21fil/25263015B  RdSum: 31fil/21831414B
CZHETH3C: End of Q SYS display
----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
send -c zvm1 q sys
ZVM1: Link                         Line
ZVM1: Name     Status     Type     Addr LU Name  Logmode  Queueing
ZVM1: ZOS2     connect    SNANJE   0000 A06JES2  RSCSNJE0 size
ZVM1: CZHETH3C connect    TCPNJE   0000 ...      ...      size
ZVM1: 2 links found
----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
send -c zos1 '$DNET'
ZOS1: 14.09.42          $HASP899 $DNET
ZOS1: 14.09.42          $HASP899 ACTIVE NETWORKING DEVICES
ZOS1: 14.09.42          $HASP899 NAME                             STATUS
ZOS1: 14.09.42          $HASP899 -----------------------------------------------
ZOS1: 14.09.42          $HASP899 LOGON1                           ACTIVE
ZOS1: 14.09.42          $HASP899 LINE1                            ACTIVE/ZOS2
----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8
send -c zos2 '$DNET'
ZOS2: 14.08.53          $HASP899 $DNET
ZOS2: 14.08.53          $HASP899 ACTIVE NETWORKING DEVICES
ZOS2: 14.08.53          $HASP899 NAME                             STATUS
ZOS2: 14.08.53          $HASP899 -----------------------------------------------
ZOS2: 14.08.53          $HASP899 LOGON1                           ACTIVE
ZOS2: 14.08.53          $HASP899 LINE1                            ACTIVE/ZOS1
ZOS2: 14.08.53          $HASP899 LINE2                            ACTIVE/ZVM1
----+----1----+----2----+----3----+----4----+----5----+----6----+----7----+----8

____
2019-10-22, Juergen Winkelmann, ETH Zuerich
winkelmann@id.ethz.ch
