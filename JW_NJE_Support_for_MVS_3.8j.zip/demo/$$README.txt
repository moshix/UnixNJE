                      Hybrid NJE Support for MVS 3.8j
                      _______________________________


                             Proof of Concept
                             ----------------

This folder documents an example of sending a file around in the proof of concept NJE network:

                  +------------+               +------------+
                  |  CZHETH3C  |    TCPNJE     |    ZVM1    |
                  |  MVS 3.8j  |---------------|  z/VM 6.3  |
                  |  FUNET-NJE |               |    RSCS    |
                  +------------+               +------------+
                                                      |
                                                      |
                                                      | SNANJE
                                                      |
                                                      |
                  +------------+               +------------+
                  |    ZOS1    |    SNANJE     |    ZOS2    |
                  |  z/OS 1.10 |---------------|  z/OS 2.3  |
                  |    JES2    |               |    JES2    |
                  +------------+               +------------+

Index:

$$README.txt     -- this file
czheth3c_log.pdf -- log of TSO session on CZHETH3C
zos1_log.pdf     -- log of TSO session on ZOS1
zvm1_log.pdf     -- log of CMS session on ZVM1
NJE.png          -- screen shot of all three sessions
funetnje.layout  -- the file being sent around in this example

Example proceeding:

- send FUNETNJE LAYOUT A from ZVM1 to CZHETH3C
- receive the file as JUERGEN.FUNETNJE.LAYOUT on CZHETH3C
- send JUERGEN.FUNETNJE.LAYOUT to ZOS1
- receive the file as JUERGEN.FUNETNJE.LAYOUT.ZOS1 on ZOS1
- send JUERGEN.FUNETNJE.LAYOUT.ZOS1 to ZVM1
- receive the file as FUNETNJE LAYOUTZ1 A on ZVM1
- compare FUNETNJE LAYOUT A with FUNETNJE LAYOUTZ1 A

The screen shot is a mosaic of the log files and the 3270 terminal sessions
showing every terminal action, except the receive operation on CZHETH3C: On
MVS 3.8j, there is no line mode command to read a specific spool dataset like
the RECEIVE commands on z/VM CMS and z/OS TSO/E. Instead, we have the QUEUE full
screen program on MVS 3.8j TSO to handle spool files (or alternatively RFE menu
3.8 -- Outlist, but with less functionality). Showing the QUEUE screens simply
wouldn't have fit on the screen shot, but those can be found in czheth3c_log.pdf.


____
2019-10-22, Juergen Winkelmann, ETH Zuerich
winkelmann@id.ethz.ch
